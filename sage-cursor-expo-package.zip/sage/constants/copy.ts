// Shared product copy. The Visual Check disclaimer is REQUIRED on every result screen —
// legal-reviewed language; do not paraphrase in components.
export const VISUAL_CHECK_DISCLAIMER =
  "Visual Check is an AI-assisted second opinion based on your photo. It is not a certified " +
  "authentication or appraisal. For high-value purchases, consult a qualified mineralogist " +
  "or testing lab.";

export const FREE_TIER = { checksPerMonth: 3, catalogCap: 25 } as const;

export const PAYWALL = {
  title: "Go unlimited with Sage+",
  bullets: [
    "Unlimited Visual Checks",
    "Unlimited cataloging",
    "Collection valuation analytics",
  ],
  price: "$7/month · first month free",
  cta: "Start free month",
  dismiss: "Maybe later",
} as const;

export const ESCROW_EXPLAINER = {
  held: "Payment held in escrow until you confirm delivery.",
  shipping: "Tracked shipping required. Funds release after delivery is confirmed.",
} as const;
