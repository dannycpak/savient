// Sage design tokens — taken directly from the approved prototype (Sage Screens.dc.html).
// Field-journal calm: warm bone ground, ink text, sage green as the single accent.
export const colors = {
  bg: "#EBE7DD",        // warm bone — app background
  surface: "#F4F1E9",   // raised card
  ink: "#22281F",       // primary text
  muted: "#6C7265",     // secondary text
  faint: "#98938A",     // labels / eyebrows
  green: "#46594A",     // primary actions, links
  greenDeep: "#2E3B31", // pressed / hover
  line: "#D9D4C7",      // hairline dividers
  danger: "#8C4A3C",    // destructive, muted terracotta (delete account, disputes)
  success: "#4A6B52",
} as const;

export const fonts = {
  display: "InstrumentSerif_400Regular", // headlines, collection value
  body: "InstrumentSans_400Regular",
  medium: "InstrumentSans_500Medium",
  semibold: "InstrumentSans_600SemiBold",
} as const;

export const space = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48 } as const;
export const radius = { sm: 8, md: 12, lg: 16, pill: 999 } as const;

export const type = {
  hero: { fontFamily: fonts.display, fontSize: 40, color: colors.ink },
  h1: { fontFamily: fonts.display, fontSize: 28, color: colors.ink },
  h2: { fontFamily: fonts.semibold, fontSize: 18, color: colors.ink },
  body: { fontFamily: fonts.body, fontSize: 15, color: colors.ink, lineHeight: 22 },
  caption: { fontFamily: fonts.body, fontSize: 13, color: colors.muted },
  eyebrow: {
    fontFamily: fonts.semibold, fontSize: 12, color: colors.faint,
    letterSpacing: 0.6, textTransform: "uppercase" as const,
  },
} as const;
