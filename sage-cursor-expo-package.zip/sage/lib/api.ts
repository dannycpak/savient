// Single gateway for Edge Function calls. Attaches the current session bearer token.
// No screen should build a functions URL by hand.
import { supabase } from "./supabase";

const BASE = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1`;

export class ApiError extends Error {
  constructor(public status: number, public body: Record<string, unknown>) {
    super(String(body?.error ?? status));
  }
}

async function call<T>(fn: string, payload: unknown): Promise<T> {
  const { data: { session } } = await supabase.auth.getSession();
  const res = await fetch(`${BASE}/${fn}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(session ? { Authorization: `Bearer ${session.access_token}` } : {}),
    },
    body: JSON.stringify(payload),
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, body);
  return body as T;
}

export type VisualCheckResult = {
  id: string;
  consumed: "allowance" | "credit";
  result: {
    candidates: { species: string; confidence: number; notes: string }[];
    red_flags: string[];
    observations: string;
    price_context: string;
  };
};

export const api = {
  visualCheck: (image_path: string) =>
    call<VisualCheckResult>("visual-check", { image_path }),
  createOrder: (listing_id: string) =>
    call<{ order_id: string; client_secret: string }>("create-order", { listing_id }),
  confirmDelivery: (order_id: string) =>
    call<{ ok: true }>("confirm-delivery", { order_id }),
};
