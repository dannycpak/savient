// visual-check — AI Visual Check proxy (JWT-verified).
// Flow: gate quota (allowance → credits) → fetch signed image → Anthropic vision → persist.
// Deploy: supabase functions deploy visual-check
import { createClient } from "npm:@supabase/supabase-js@2";
import Anthropic from "npm:@anthropic-ai/sdk";
import { preflight, json } from "../_shared/cors.ts";

const SYSTEM_PROMPT = `You are a mineral identification assistant for collectors. Given a
photo of a mineral specimen, respond ONLY with JSON (no prose, no markdown fences):
{
  "candidates": [{"species": string, "confidence": number 0-1, "notes": string}],
  "red_flags": [string],   // species-specific: dye, heat treatment, implausible locality/price, common fakes
  "observations": string,  // habit, luster, matrix, crystal form seen in the photo
  "price_context": string  // qualitative only; no invented dollar figures
}
This is a second opinion, not a certified authentication. If the image is not a mineral
specimen, return candidates: [] and explain in observations.`;

Deno.serve(async (req) => {
  const pre = preflight(req);
  if (pre) return pre;

  try {
    const auth = req.headers.get("Authorization") ?? "";
    // User-scoped client: RLS applies for reads; service client for privileged writes.
    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: auth } } },
    );
    const service = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: { user }, error: userErr } = await userClient.auth.getUser();
    if (userErr || !user) return json({ error: "unauthorized" }, 401);

    const { image_path } = await req.json();
    if (!image_path || typeof image_path !== "string") {
      return json({ error: "image_path required" }, 400);
    }

    // 1) Gate + consume atomically (allowance first, then credits). Raises if none left.
    const { data: consumed, error: gateErr } = await service.rpc("consume_check", {
      p_user: user.id,
    });
    if (gateErr) {
      if (gateErr.message?.includes("NO_CHECKS_REMAINING")) {
        return json({ error: "no_checks_remaining", paywall: true }, 402);
      }
      return json({ error: gateErr.message }, 500);
    }

    // 2) Create the job row.
    const { data: job, error: jobErr } = await service
      .from("visual_checks")
      .insert({
        user_id: user.id,
        image_path,
        status: "processing",
        consumed,
      })
      .select()
      .single();
    if (jobErr) return json({ error: jobErr.message }, 500);

    // 3) Pull the image (private bucket → signed URL → base64).
    const { data: signed } = await service.storage
      .from("check-uploads")
      .createSignedUrl(image_path, 60);
    if (!signed?.signedUrl) return json({ error: "image not found" }, 404);

    const imgResp = await fetch(signed.signedUrl);
    const buf = new Uint8Array(await imgResp.arrayBuffer());
    let b64 = "";
    const CHUNK = 0x8000;
    for (let i = 0; i < buf.length; i += CHUNK) {
      b64 += String.fromCharCode(...buf.subarray(i, i + CHUNK));
    }
    b64 = btoa(b64);
    const mediaType = imgResp.headers.get("content-type") ?? "image/jpeg";

    // 4) Anthropic vision call (key lives ONLY here).
    const anthropic = new Anthropic({ apiKey: Deno.env.get("ANTHROPIC_API_KEY")! });
    const model = "claude-sonnet-4-6";
    const msg = await anthropic.messages.create({
      model,
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages: [{
        role: "user",
        content: [
          { type: "image", source: { type: "base64", media_type: mediaType, data: b64 } },
          { type: "text", text: "Identify this specimen." },
        ],
      }],
    });

    const raw = msg.content.filter((b) => b.type === "text").map((b) => b.text).join("\n");
    let result: unknown;
    try {
      result = JSON.parse(raw.replace(/```json|```/g, "").trim());
    } catch {
      result = { candidates: [], red_flags: [], observations: raw, price_context: "" };
    }
    const confidence =
      (result as { candidates?: { confidence?: number }[] })?.candidates?.[0]?.confidence ?? null;

    // 5) Persist result.
    await service.from("visual_checks").update({
      status: "complete",
      model_used: model,
      result_json: result,
      confidence,
      completed_at: new Date().toISOString(),
    }).eq("id", job.id);

    return json({ id: job.id, consumed, result });
  } catch (e) {
    console.error("visual-check error", e);
    return json({ error: "internal_error" }, 500);
  }
});
