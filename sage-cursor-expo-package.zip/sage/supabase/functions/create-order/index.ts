// create-order — buyer starts an escrowed purchase (JWT-verified).
// Destination charge to the seller's connected account, MANUAL capture, platform fee.
// Client never sends an amount: price is read from the listing row.
import Stripe from "npm:stripe@^17";
import { createClient } from "npm:@supabase/supabase-js@2";
import { preflight, json } from "../_shared/cors.ts";

const PLATFORM_FEE_BPS = 1000; // 10.00% — adjust with finance before launch

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, {
  httpClient: Stripe.createFetchHttpClient(),
});

Deno.serve(async (req) => {
  const pre = preflight(req);
  if (pre) return pre;

  try {
    const auth = req.headers.get("Authorization") ?? "";
    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: auth } } },
    );
    const service = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return json({ error: "unauthorized" }, 401);

    const { listing_id } = await req.json();
    const { data: listing } = await service
      .from("listings")
      .select("id, price_cents, currency, status, seller_id, sellers ( id, profile_id, stripe_connect_account_id, connect_onboarding_status )")
      .eq("id", listing_id)
      .single();

    if (!listing || listing.status !== "active") return json({ error: "listing unavailable" }, 409);
    const seller = listing.sellers as unknown as {
      id: string; profile_id: string;
      stripe_connect_account_id: string | null;
      connect_onboarding_status: string;
    };
    if (seller.profile_id === user.id) return json({ error: "cannot buy own listing" }, 400);
    if (!seller.stripe_connect_account_id || seller.connect_onboarding_status !== "active") {
      return json({ error: "seller not ready to receive payments" }, 409);
    }

    const fee = Math.round(listing.price_cents * PLATFORM_FEE_BPS / 10000);

    // Order row first so its id doubles as the Stripe idempotency key.
    const { data: order, error: orderErr } = await service.from("orders").insert({
      listing_id: listing.id,
      buyer_id: user.id,
      seller_id: seller.id,
      amount_cents: listing.price_cents,
      platform_fee_cents: fee,
      status: "pending",
    }).select().single();
    if (orderErr) return json({ error: orderErr.message }, 500);

    const intent = await stripe.paymentIntents.create({
      amount: listing.price_cents,
      currency: listing.currency,
      capture_method: "manual",                       // escrow: authorize now, capture on delivery
      application_fee_amount: fee,
      transfer_data: { destination: seller.stripe_connect_account_id },
      metadata: { order_id: order.id, listing_id: listing.id, buyer_id: user.id },
    }, { idempotencyKey: order.id });

    await service.from("orders")
      .update({ stripe_payment_intent_id: intent.id })
      .eq("id", order.id);

    return json({ order_id: order.id, client_secret: intent.client_secret });
  } catch (e) {
    console.error("create-order error", e);
    return json({ error: "internal_error" }, 500);
  }
});
