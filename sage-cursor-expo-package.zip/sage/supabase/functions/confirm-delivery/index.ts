// confirm-delivery — buyer confirms receipt (or a scheduled job auto-confirms 7 days
// after tracked delivery). Captures the manual PaymentIntent → funds transfer to seller
// minus platform fee. JWT-verified for the buyer path.
import Stripe from "npm:stripe@^17";
import { createClient } from "npm:@supabase/supabase-js@2";
import { preflight, json } from "../_shared/cors.ts";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, {
  httpClient: Stripe.createFetchHttpClient(),
});

Deno.serve(async (req) => {
  const pre = preflight(req);
  if (pre) return pre;

  try {
    const auth = req.headers.get("Authorization") ?? "";
    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: auth } } },
    );
    const service = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return json({ error: "unauthorized" }, 401);

    const { order_id } = await req.json();
    const { data: order } = await service.from("orders")
      .select("*").eq("id", order_id).single();
    if (!order) return json({ error: "order not found" }, 404);
    if (order.buyer_id !== user.id) return json({ error: "forbidden" }, 403);
    if (!["escrow_held", "shipped", "delivered"].includes(order.status)) {
      return json({ error: `cannot confirm from status ${order.status}` }, 409);
    }

    await stripe.paymentIntents.capture(order.stripe_payment_intent_id, undefined, {
      idempotencyKey: `capture-${order.id}`,
    });
    // stripe-webhook (payment_intent.succeeded) flips status → released and listing → sold.

    return json({ ok: true });
  } catch (e) {
    console.error("confirm-delivery error", e);
    return json({ error: "internal_error" }, 500);
  }
});
