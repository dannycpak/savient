// stripe-webhook — physical-goods rail only (marketplace escrow + Connect onboarding).
// Deploy: supabase functions deploy stripe-webhook --no-verify-jwt
// MUST verify signatures itself via Deno subtle crypto (see .cursorrules rule 2).
import Stripe from "npm:stripe@^17";
import { createClient } from "npm:@supabase/supabase-js@2";
import { json } from "../_shared/cors.ts";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, {
  httpClient: Stripe.createFetchHttpClient(),
});
const cryptoProvider = Stripe.createSubtleCryptoProvider();

Deno.serve(async (req) => {
  const signature = req.headers.get("Stripe-Signature");
  const body = await req.text();
  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(
      body,
      signature!,
      Deno.env.get("STRIPE_WEBHOOK_SECRET")!,
      undefined,
      cryptoProvider,
    );
  } catch (e) {
    console.error("signature verification failed", e);
    return json({ error: "invalid signature" }, 400);
  }

  const service = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  try {
    switch (event.type) {
      case "account.updated": {
        const acct = event.data.object as Stripe.Account;
        const status = acct.charges_enabled && acct.payouts_enabled
          ? "active"
          : acct.requirements?.disabled_reason
          ? "restricted"
          : "pending";
        await service.from("sellers")
          .update({ connect_onboarding_status: status })
          .eq("stripe_connect_account_id", acct.id);
        break;
      }
      case "payment_intent.amount_capturable_updated": {
        // Authorization succeeded on a manual-capture intent → funds held → escrow.
        const pi = event.data.object as Stripe.PaymentIntent;
        await service.from("orders")
          .update({ status: "escrow_held", updated_at: new Date().toISOString() })
          .eq("stripe_payment_intent_id", pi.id)
          .eq("status", "pending");
        break;
      }
      case "payment_intent.succeeded": {
        // Capture completed (confirm-delivery) → funds transferring → released.
        const pi = event.data.object as Stripe.PaymentIntent;
        await service.from("orders")
          .update({ status: "released", updated_at: new Date().toISOString() })
          .eq("stripe_payment_intent_id", pi.id);
        // Mark the listing sold.
        const { data: order } = await service.from("orders")
          .select("listing_id").eq("stripe_payment_intent_id", pi.id).single();
        if (order) {
          await service.from("listings").update({ status: "sold" }).eq("id", order.listing_id);
        }
        break;
      }
      case "payment_intent.canceled":
      case "charge.refunded": {
        const obj = event.data.object as Stripe.PaymentIntent | Stripe.Charge;
        const piId = "payment_intent" in obj && obj.payment_intent
          ? String(obj.payment_intent)
          : obj.id;
        await service.from("orders")
          .update({ status: "refunded", updated_at: new Date().toISOString() })
          .eq("stripe_payment_intent_id", piId);
        break;
      }
      case "charge.dispute.created": {
        const ch = event.data.object as Stripe.Charge;
        await service.from("orders")
          .update({ status: "disputed", updated_at: new Date().toISOString() })
          .eq("stripe_payment_intent_id", String(ch.payment_intent));
        break;
      }
      default:
        break;
    }
    return json({ received: true });
  } catch (e) {
    console.error("stripe-webhook error", e);
    return json({ error: "internal_error" }, 500);
  }
});
