// revenuecat-webhook — digital-goods truth source (Sage+ entitlement, credit packs).
// Deploy: supabase functions deploy revenuecat-webhook --no-verify-jwt
// Auth: RevenueCat sends `Authorization: Bearer <REVENUECAT_WEBHOOK_AUTH>` — set the same
// value in the RC dashboard webhook config and in `supabase secrets set`.
import { createClient } from "npm:@supabase/supabase-js@2";
import { json } from "../_shared/cors.ts";

// Map RC consumable product IDs → credits granted. Keep in sync with store products.
const CREDIT_PRODUCTS: Record<string, number> = {
  "sage_credits_5": 5,
  "sage_credits_15": 15,
  "sage_credits_40": 40,
};

Deno.serve(async (req) => {
  const expected = Deno.env.get("REVENUECAT_WEBHOOK_AUTH");
  if (!expected || req.headers.get("Authorization") !== `Bearer ${expected}`) {
    return json({ error: "unauthorized" }, 401);
  }

  const service = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const { event } = await req.json();
  // RC app_user_id should be set to the Supabase auth.users.id at SDK configure time.
  const userId: string | undefined = event?.app_user_id;
  if (!userId) return json({ ok: true, skipped: "no app_user_id" });

  const type: string = event?.type ?? "";
  const productId: string = event?.product_id ?? "";
  const store = event?.store === "PLAY_STORE" ? "play" : "app_store";

  try {
    switch (type) {
      // ---- Sage+ subscription entitlement ----
      case "INITIAL_PURCHASE":
      case "RENEWAL":
      case "UNCANCELLATION":
      case "PRODUCT_CHANGE": {
        if (productId in CREDIT_PRODUCTS) break; // consumables handled below via NON_RENEWING
        const status = event?.period_type === "TRIAL" ? "trialing" : "active";
        await service.from("subscriptions").upsert({
          user_id: userId,
          rc_app_user_id: userId,
          rc_entitlement: "plus",
          status,
          store,
          renews_at: event?.expiration_at_ms
            ? new Date(event.expiration_at_ms).toISOString()
            : null,
          updated_at: new Date().toISOString(),
        });
        await service.from("profiles").update({ plan: "plus" }).eq("id", userId);
        break;
      }
      case "CANCELLATION": {
        // User turned off auto-renew — entitlement persists until expiration.
        await service.from("subscriptions")
          .update({ status: "canceled", updated_at: new Date().toISOString() })
          .eq("user_id", userId);
        break;
      }
      case "EXPIRATION": {
        await service.from("subscriptions")
          .update({ status: "expired", updated_at: new Date().toISOString() })
          .eq("user_id", userId);
        await service.from("profiles").update({ plan: "free" }).eq("id", userId);
        break;
      }
      case "BILLING_ISSUE": {
        // Grace period: mark it, gate checks in-app, do NOT hard-cancel.
        await service.from("subscriptions")
          .update({ status: "billing_issue", updated_at: new Date().toISOString() })
          .eq("user_id", userId);
        break;
      }
      // ---- Visual Check credit packs (consumables) ----
      case "NON_RENEWING_PURCHASE": {
        const credits = CREDIT_PRODUCTS[productId];
        if (!credits) break;
        // rc_transaction_id unique constraint = idempotency against RC retries.
        const { error } = await service.from("credit_ledger").insert({
          user_id: userId,
          delta: credits,
          reason: "purchase",
          rc_transaction_id: event?.transaction_id ?? event?.id,
        });
        if (error && !error.message.includes("duplicate")) throw error;
        break;
      }
      default:
        break; // TRANSFER, SUBSCRIBER_ALIAS etc. — log only
    }
    return json({ ok: true });
  } catch (e) {
    console.error("revenuecat-webhook error", e);
    return json({ error: "internal_error" }, 500); // RC retries on 5xx
  }
});
