-- Sage initial schema: profiles, catalog, visual checks, marketplace, billing mirrors.
-- Tenancy = row-level ownership. RLS on everywhere; public reads are explicit policies.

-- ============ ENUMS ============
create type plan_t              as enum ('free','plus');
create type visibility_t        as enum ('private','public');
create type check_status_t      as enum ('queued','processing','complete','failed');
create type check_consumed_t    as enum ('allowance','credit');
create type seller_tier_t       as enum ('self_certified','documented','lab_verified');
create type connect_status_t    as enum ('pending','active','restricted');
create type listing_status_t    as enum ('draft','active','sold','cancelled');
create type order_status_t      as enum ('pending','escrow_held','shipped','delivered','disputed','released','refunded');
create type accuracy_t          as enum ('as_described','minor','not_as_described');
create type sub_status_t        as enum ('trialing','active','canceled','expired','billing_issue');
create type store_t             as enum ('app_store','play','stripe_web');
create type ledger_reason_t     as enum ('purchase','check_used','grant','refund');

-- ============ PROFILES ============
create table profiles (
  id                uuid primary key references auth.users(id) on delete cascade,
  username          text unique,
  display_name      text,
  avatar_url        text,
  plan              plan_t not null default 'free',
  checks_used_month int not null default 0,
  checks_month_key  text not null default to_char(now(),'YYYY-MM'),
  deleted_at        timestamptz,                    -- soft delete; purge job after 30 days
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

-- auto-create profile on signup
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name) values (new.id, new.raw_user_meta_data->>'name');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============ CATALOG ============
create table specimens (
  id                      uuid primary key default gen_random_uuid(),
  owner_id                uuid not null references profiles(id) on delete cascade,
  species                 text not null,
  variety                 text,
  locality                text,
  formation               text,
  matrix                  text,
  dims                    jsonb,                     -- {l,w,h,unit}
  weight_value            numeric,
  weight_unit             text check (weight_unit in ('ct','g','kg')),
  condition               text,
  rarity                  text,
  provenance              text,
  acquired_at             date,
  acquisition_price_cents int,
  est_value_cents         int,
  visibility              visibility_t not null default 'private',
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now()
);
create index on specimens (owner_id);

create table specimen_photos (
  id           uuid primary key default gen_random_uuid(),
  specimen_id  uuid not null references specimens(id) on delete cascade,
  storage_path text not null,
  is_primary   boolean not null default false,
  uploaded_at  timestamptz not null default now()
);
create index on specimen_photos (specimen_id);

-- ============ VISUAL CHECKS ============
create table visual_checks (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references profiles(id) on delete cascade,
  image_path   text not null,
  status       check_status_t not null default 'queued',
  model_used   text,
  result_json  jsonb,            -- keep as raw structured model output; schema will evolve
  confidence   numeric,
  consumed     check_consumed_t,
  created_at   timestamptz not null default now(),
  completed_at timestamptz
);
create index on visual_checks (user_id, created_at desc);

-- ============ SELLERS / MARKETPLACE ============
create table sellers (
  id                        uuid primary key default gen_random_uuid(),
  profile_id                uuid not null unique references profiles(id) on delete cascade,
  business_name             text,
  tier                      seller_tier_t not null default 'self_certified',
  credibility_score         numeric not null default 0,   -- 0..10, recomputed on rating
  ratings_count             int not null default 0,
  docs_review_flag          boolean not null default false, -- ops-set; required for tier upgrades
  stripe_connect_account_id text unique,
  connect_onboarding_status connect_status_t not null default 'pending',
  created_at                timestamptz not null default now()
);

create table listings (
  id             uuid primary key default gen_random_uuid(),
  seller_id      uuid not null references sellers(id) on delete cascade,
  specimen_id    uuid references specimens(id) on delete set null,
  title          text not null,
  description    text,
  species        text,
  locality       text,
  price_cents    int not null check (price_cents > 0),
  currency       text not null default 'usd',
  photo_verified boolean not null default false,
  status         listing_status_t not null default 'draft',
  created_at     timestamptz not null default now()
);
create index on listings (status, created_at desc);

create table orders (
  id                       uuid primary key default gen_random_uuid(),
  listing_id               uuid not null references listings(id),
  buyer_id                 uuid not null references profiles(id),
  seller_id                uuid not null references sellers(id),
  amount_cents             int not null,
  platform_fee_cents       int not null,
  stripe_payment_intent_id text unique,
  tracking_number          text,
  status                   order_status_t not null default 'pending',
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now()
);
create index on orders (buyer_id); create index on orders (seller_id);

create table ratings (
  id          uuid primary key default gen_random_uuid(),
  order_id    uuid not null unique references orders(id),   -- one rating per order
  buyer_id    uuid not null references profiles(id),
  seller_id   uuid not null references sellers(id),
  accuracy    accuracy_t not null,
  photo_match boolean not null,
  created_at  timestamptz not null default now()
);

-- recency-weighted credibility recompute (simple exponential decay by rating order)
create or replace function public.recompute_credibility(p_seller uuid) returns void
language sql security definer set search_path = public as $$
  update sellers s set
    credibility_score = coalesce((
      select round( least(10, greatest(0,
        sum(w * v) / nullif(sum(w),0) * 10 ))::numeric, 2)
      from (
        select
          power(0.9, row_number() over (order by created_at desc) - 1) as w,
          case accuracy when 'as_described' then 1.0
                        when 'minor'        then 0.6
                        else 0.0 end
          * case when photo_match then 1.0 else 0.85 end as v
        from ratings where seller_id = p_seller
      ) t), 0),
    ratings_count = (select count(*) from ratings where seller_id = p_seller)
  where s.id = p_seller;
$$;

create or replace function public.on_rating_insert() returns trigger
language plpgsql security definer set search_path = public as $$
begin perform public.recompute_credibility(new.seller_id); return new; end $$;
create trigger trg_rating_insert after insert on ratings
  for each row execute function public.on_rating_insert();

-- ============ BILLING MIRRORS ============
create table subscriptions (
  user_id        uuid primary key references profiles(id) on delete cascade,
  rc_app_user_id text,
  rc_entitlement text,
  status         sub_status_t not null default 'expired',
  store          store_t,
  renews_at      timestamptz,
  updated_at     timestamptz not null default now()
);

create table credit_ledger (                        -- APPEND-ONLY
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null references profiles(id) on delete cascade,
  delta             int not null,
  reason            ledger_reason_t not null,
  rc_transaction_id text unique,                    -- idempotency for RC consumables
  created_at        timestamptz not null default now()
);
create index on credit_ledger (user_id);

create or replace function public.credit_balance(p_user uuid) returns int
language sql stable security definer set search_path = public as
$$ select coalesce(sum(delta),0)::int from credit_ledger where user_id = p_user $$;

-- Atomic gate + consume for a visual check. Returns what was consumed or raises.
create or replace function public.consume_check(p_user uuid)
returns check_consumed_t language plpgsql security definer set search_path = public as $$
declare v_plan plan_t; v_used int; v_key text; v_now_key text := to_char(now(),'YYYY-MM');
begin
  select plan, checks_used_month, checks_month_key into v_plan, v_used, v_key
    from profiles where id = p_user for update;
  if v_key <> v_now_key then
    update profiles set checks_used_month = 0, checks_month_key = v_now_key where id = p_user;
    v_used := 0;
  end if;
  if v_plan = 'plus' then
    update profiles set checks_used_month = checks_used_month + 1 where id = p_user;
    return 'allowance';
  end if;
  if v_used < 3 then
    update profiles set checks_used_month = checks_used_month + 1 where id = p_user;
    return 'allowance';
  end if;
  if public.credit_balance(p_user) >= 1 then
    insert into credit_ledger (user_id, delta, reason) values (p_user, -1, 'check_used');
    return 'credit';
  end if;
  raise exception 'NO_CHECKS_REMAINING' using errcode = 'P0001';
end $$;

-- ============ ROW LEVEL SECURITY ============
alter table profiles        enable row level security;
alter table specimens       enable row level security;
alter table specimen_photos enable row level security;
alter table visual_checks   enable row level security;
alter table sellers         enable row level security;
alter table listings        enable row level security;
alter table orders          enable row level security;
alter table ratings         enable row level security;
alter table subscriptions   enable row level security;
alter table credit_ledger   enable row level security;

-- profiles: owner full access; public basic read (marketplace identity)
create policy profiles_self   on profiles for all    using (id = auth.uid());
create policy profiles_public on profiles for select using (deleted_at is null);

-- specimens: owner CRUD; public read when shared
create policy specimens_owner  on specimens for all    using (owner_id = auth.uid());
create policy specimens_public on specimens for select using (visibility = 'public');
create policy photos_owner on specimen_photos for all using (
  exists (select 1 from specimens s where s.id = specimen_id and s.owner_id = auth.uid()));
create policy photos_public on specimen_photos for select using (
  exists (select 1 from specimens s where s.id = specimen_id and s.visibility = 'public'));

-- visual checks: owner only (writes happen via edge function w/ service role or owner insert)
create policy checks_owner on visual_checks for all using (user_id = auth.uid());

-- sellers: self manage; everyone can read active seller profiles
create policy sellers_self   on sellers for all    using (profile_id = auth.uid());
create policy sellers_public on sellers for select using (true);

-- listings: seller CRUD; public read of active
create policy listings_seller on listings for all using (
  exists (select 1 from sellers s where s.id = seller_id and s.profile_id = auth.uid()));
create policy listings_public on listings for select using (status = 'active');

-- orders: visible to buyer and seller; created only via edge function (service role)
create policy orders_parties on orders for select using (
  buyer_id = auth.uid()
  or exists (select 1 from sellers s where s.id = seller_id and s.profile_id = auth.uid()));

-- ratings: buyer inserts own, once per order (unique constraint); public read
create policy ratings_insert on ratings for insert with check (buyer_id = auth.uid());
create policy ratings_public on ratings for select using (true);

-- billing mirrors: read own; writes only via service role (webhooks)
create policy subs_self   on subscriptions  for select using (user_id = auth.uid());
create policy ledger_self on credit_ledger  for select using (user_id = auth.uid());
