import { useState } from "react";
import { Alert, Text } from "react-native";
import { supabase } from "@/lib/supabase";
import { Screen, Button, Field } from "@/components/ui";
import { space, type } from "@/constants/theme";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  const send = async () => {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: "sage://reset-password",
    });
    if (error) Alert.alert("Couldn't send link", error.message);
    else setSent(true);
  };

  return (
    <Screen style={{ justifyContent: "center", gap: space.md }}>
      <Text style={type.h1}>{sent ? "Check your inbox" : "Reset password"}</Text>
      {sent ? (
        <Text style={type.body}>We sent a reset link to {email}. Open it on this device.</Text>
      ) : (
        <>
          <Field label="Email" value={email} onChangeText={setEmail}
            autoCapitalize="none" keyboardType="email-address" />
          <Button label="Send reset link" onPress={send} />
        </>
      )}
    </Screen>
  );
}
