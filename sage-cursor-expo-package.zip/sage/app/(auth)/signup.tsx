import { useState } from "react";
import { Alert, Text } from "react-native";
import { Link, router } from "expo-router";
import { supabase } from "@/lib/supabase";
import { Screen, Button, Field } from "@/components/ui";
import { space, type } from "@/constants/theme";

export default function Signup() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const signUp = async () => {
    setBusy(true);
    const { error } = await supabase.auth.signUp({
      email, password, options: { data: { name } },
    });
    setBusy(false);
    if (error) return Alert.alert("Couldn't create account", error.message);
    router.replace("/(tabs)");
  };

  return (
    <Screen style={{ justifyContent: "center", gap: space.md }}>
      <Text style={type.h1}>Create your account</Text>
      <Field label="Full name" value={name} onChangeText={setName} />
      <Field label="Email" value={email} onChangeText={setEmail}
        autoCapitalize="none" keyboardType="email-address" />
      <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry />
      <Button label="Create account" onPress={signUp} loading={busy} />
      <Link href="/(auth)/login" style={[type.caption, { textAlign: "center" }]}>
        Already have an account? Log in
      </Link>
    </Screen>
  );
}
