import { useState } from "react";
import { Alert, Text } from "react-native";
import { Link, router } from "expo-router";
import * as AppleAuthentication from "expo-apple-authentication";
import { supabase } from "@/lib/supabase";
import { Screen, Button, Field } from "@/components/ui";
import { space, type } from "@/constants/theme";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const signIn = async () => {
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) return Alert.alert("Couldn't log in", error.message);
    router.replace("/(tabs)");
  };

  const signInWithApple = async () => {
    try {
      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });
      if (!cred.identityToken) return;
      const { error } = await supabase.auth.signInWithIdToken({
        provider: "apple", token: cred.identityToken,
      });
      if (error) Alert.alert("Apple sign-in failed", error.message);
      else router.replace("/(tabs)");
    } catch { /* user canceled */ }
  };

  return (
    <Screen style={{ justifyContent: "center", gap: space.md }}>
      <Text style={type.h1}>Log in</Text>
      <Field label="Email" value={email} onChangeText={setEmail}
        autoCapitalize="none" keyboardType="email-address" />
      <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry />
      <Button label="Log in" onPress={signIn} loading={busy} />
      <Button label="Continue with Apple" variant="ghost" onPress={signInWithApple} />
      <Link href="/(auth)/forgot-password" style={[type.caption, { textAlign: "center" }]}>
        Forgot password?
      </Link>
      <Link href="/(auth)/signup" style={[type.caption, { textAlign: "center" }]}>
        New here? Create an account
      </Link>
    </Screen>
  );
}
