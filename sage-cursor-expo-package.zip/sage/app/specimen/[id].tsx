// Specimen detail / create. Route "new" = create form; otherwise show + edit.
import { useEffect, useState } from "react";
import { Alert, ScrollView, Text } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { supabase } from "@/lib/supabase";
import { Screen, Card, Button, Field, Eyebrow } from "@/components/ui";
import { space, type } from "@/constants/theme";

export default function Specimen() {
  const { id, species: prefillSpecies } = useLocalSearchParams<{ id: string; species?: string }>();
  const isNew = id === "new";
  const [species, setSpecies] = useState(prefillSpecies ?? "");
  const [locality, setLocality] = useState("");
  const [provenance, setProvenance] = useState("");
  const [estValue, setEstValue] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (isNew) return;
    supabase.from("specimens").select("*").eq("id", id).single().then(({ data }) => {
      if (!data) return;
      setSpecies(data.species); setLocality(data.locality ?? "");
      setProvenance(data.provenance ?? "");
      setEstValue(data.est_value_cents != null ? String(data.est_value_cents / 100) : "");
    });
  }, [id]);

  const save = async () => {
    setBusy(true);
    const payload = {
      species,
      locality: locality || null,
      provenance: provenance || null,
      est_value_cents: estValue ? Math.round(parseFloat(estValue) * 100) : null,
    };
    const { data: { user } } = await supabase.auth.getUser();
    const q = isNew
      ? supabase.from("specimens").insert({ ...payload, owner_id: user!.id })
      : supabase.from("specimens").update(payload).eq("id", id);
    const { error } = await q;
    setBusy(false);
    if (error) return Alert.alert("Couldn't save", error.message);
    router.back();
  };

  return (
    <Screen style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: space.lg, gap: space.md }}>
        <Text style={type.h1}>{isNew ? "Add specimen" : species}</Text>
        <Field label="Species" value={species} onChangeText={setSpecies} />
        <Field label="Locality" value={locality} onChangeText={setLocality} />
        <Field label="Provenance" value={provenance} onChangeText={setProvenance} multiline />
        <Field label="Estimated value (USD)" value={estValue} onChangeText={setEstValue}
          keyboardType="decimal-pad" />
        <Button label={isNew ? "Save to catalog" : "Save changes"} onPress={save} loading={busy} />
        {!isNew && (
          <Card>
            <Eyebrow>Buy similar</Eyebrow>
            <Text style={type.caption}>
              Marketplace matches by species and locality appear here in Phase 4.
            </Text>
          </Card>
        )}
      </ScrollView>
    </Screen>
  );
}
