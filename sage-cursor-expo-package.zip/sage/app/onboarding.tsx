import { router } from "expo-router";
import { Text, View } from "react-native";
import { Screen, Button } from "@/components/ui";
import { colors, type, space } from "@/constants/theme";

const CARDS = [
  ["Catalog", "Specimen-grade fields: locality, formation, matrix, provenance, rarity."],
  ["Visual Check", "A photo-based second opinion — likely ID, red flags, price context."],
  ["Trust", "Seller credibility scored on material accuracy, not vibes."],
];

export default function Onboarding() {
  return (
    <Screen style={{ justifyContent: "center", gap: space.lg }}>
      <Text style={[type.hero, { textAlign: "center" }]}>Sage</Text>
      <Text style={[type.body, { textAlign: "center", color: colors.muted }]}>
        The collector platform for mineral specimens.
      </Text>
      <View style={{ gap: space.md }}>
        {CARDS.map(([h, b]) => (
          <View key={h} style={{ gap: 4 }}>
            <Text style={type.h2}>{h}</Text>
            <Text style={type.caption}>{b}</Text>
          </View>
        ))}
      </View>
      <Button label="Get started" onPress={() => router.push("/(auth)/signup")} />
      <Button label="I already have an account" variant="ghost" onPress={() => router.push("/(auth)/login")} />
    </Screen>
  );
}
