// Sage+ paywall + credit packs — RevenueCat offerings ONLY (never Stripe here).
import { useEffect, useState } from "react";
import { Alert, Text, View } from "react-native";
import { router } from "expo-router";
import type { PurchasesOffering, PurchasesPackage } from "react-native-purchases";
import { getOfferings, purchase, restore } from "@/lib/purchases";
import { Screen, Card, Button, Eyebrow } from "@/components/ui";
import { PAYWALL } from "@/constants/copy";
import { space, type } from "@/constants/theme";

export default function Paywall() {
  const [offering, setOffering] = useState<PurchasesOffering | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { getOfferings().then(setOffering).catch(() => {}); }, []);

  const buy = async (pkg: PurchasesPackage) => {
    setBusy(true);
    try {
      await purchase(pkg);
      // Server truth updates via revenuecat-webhook; UI can optimistically close.
      router.back();
    } catch (e: any) {
      if (!e?.userCancelled) Alert.alert("Purchase failed", "Please try again.");
    } finally { setBusy(false); }
  };

  return (
    <Screen style={{ gap: space.md }}>
      <Text style={type.h1}>{PAYWALL.title}</Text>
      <Card>
        {PAYWALL.bullets.map((b) => <Text key={b} style={type.body}>· {b}</Text>)}
        <Text style={[type.caption, { marginTop: space.sm }]}>{PAYWALL.price}</Text>
      </Card>
      {offering?.availablePackages.map((pkg) => (
        <Button key={pkg.identifier}
          label={pkg.packageType === "MONTHLY" ? PAYWALL.cta : `${pkg.product.title} — ${pkg.product.priceString}`}
          onPress={() => buy(pkg)} loading={busy} />
      ))}
      <Button label={PAYWALL.dismiss} variant="ghost" onPress={() => router.back()} />
      <View style={{ flex: 1 }} />
      <Text style={[type.caption, { textAlign: "center" }]}
        onPress={() => restore().then(() => Alert.alert("Purchases restored"))}>
        Restore purchases
      </Text>
    </Screen>
  );
}
