// Listing detail + buy (escrow). Phase 4: wire client_secret into Stripe PaymentSheet.
import { useEffect, useState } from "react";
import { Alert, Text } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { supabase } from "@/lib/supabase";
import { api } from "@/lib/api";
import { Screen, Card, Button, Eyebrow } from "@/components/ui";
import { ESCROW_EXPLAINER } from "@/constants/copy";
import { space, type } from "@/constants/theme";

export default function Listing() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [row, setRow] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.from("listings")
      .select("*, sellers ( id, business_name, credibility_score, tier )")
      .eq("id", id).single().then(({ data }) => setRow(data));
  }, [id]);

  const buy = async () => {
    setBusy(true);
    try {
      const { order_id, client_secret } = await api.createOrder(id);
      // Phase 4: present @stripe/stripe-react-native PaymentSheet with client_secret,
      // then route to a confirmation screen. Stub for now:
      Alert.alert("Order created", `Order ${order_id} pending payment.\n${ESCROW_EXPLAINER.held}`);
      router.push(`/checkout/${id}`);
      void client_secret;
    } catch {
      Alert.alert("Couldn't start purchase", "The listing may no longer be available.");
    } finally { setBusy(false); }
  };

  if (!row) return <Screen />;
  return (
    <Screen style={{ gap: space.md }}>
      <Text style={type.h1}>{row.title}</Text>
      <Text style={type.hero}>${(row.price_cents / 100).toLocaleString()}</Text>
      <Card>
        <Eyebrow>Seller</Eyebrow>
        <Text style={type.h2}
          onPress={() => router.push(`/seller/${row.sellers.id}`)}>
          {row.sellers?.business_name ?? "Seller"} · {row.sellers?.credibility_score?.toFixed(1)}/10
        </Text>
      </Card>
      <Card>
        <Text style={type.caption}>{ESCROW_EXPLAINER.held}</Text>
        <Text style={type.caption}>{ESCROW_EXPLAINER.shipping}</Text>
      </Card>
      <Button label="Buy" onPress={buy} loading={busy} />
    </Screen>
  );
}
