// Post-delivery rating — one per order (unique constraint enforces). Feeds credibility.
import { useState } from "react";
import { Alert, Pressable, Text, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { supabase } from "@/lib/supabase";
import { Screen, Button, Eyebrow } from "@/components/ui";
import { colors, radius, space, type } from "@/constants/theme";

const ACCURACY = [
  ["as_described", "As described"],
  ["minor", "Minor differences"],
  ["not_as_described", "Not as described"],
] as const;

function Choice({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={{
      padding: 14, borderRadius: radius.md, borderWidth: 1,
      borderColor: active ? colors.green : colors.line,
      backgroundColor: active ? colors.green : colors.surface,
    }}>
      <Text style={[type.body, { color: active ? "#fff" : colors.ink, textAlign: "center" }]}>{label}</Text>
    </Pressable>
  );
}

export default function Rate() {
  const { orderId } = useLocalSearchParams<{ orderId: string }>();
  const [accuracy, setAccuracy] = useState<string | null>(null);
  const [photoMatch, setPhotoMatch] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!accuracy || photoMatch === null) return;
    setBusy(true);
    const { data: order } = await supabase.from("orders")
      .select("seller_id, buyer_id").eq("id", orderId).single();
    const { error } = await supabase.from("ratings").insert({
      order_id: orderId, buyer_id: order!.buyer_id, seller_id: order!.seller_id,
      accuracy, photo_match: photoMatch,
    });
    setBusy(false);
    if (error) return Alert.alert("Couldn't submit", error.message);
    router.back();
  };

  return (
    <Screen style={{ gap: space.md }}>
      <Text style={type.h1}>Rate this purchase</Text>
      <Eyebrow>Material accuracy</Eyebrow>
      <View style={{ gap: space.sm }}>
        {ACCURACY.map(([v, label]) => (
          <Choice key={v} label={label} active={accuracy === v} onPress={() => setAccuracy(v)} />
        ))}
      </View>
      <Eyebrow>Did the photos match the piece?</Eyebrow>
      <View style={{ flexDirection: "row", gap: space.sm }}>
        <View style={{ flex: 1 }}>
          <Choice label="Yes, matched" active={photoMatch === true} onPress={() => setPhotoMatch(true)} />
        </View>
        <View style={{ flex: 1 }}>
          <Choice label="Not quite" active={photoMatch === false} onPress={() => setPhotoMatch(false)} />
        </View>
      </View>
      <Button label="Submit rating" onPress={submit} loading={busy}
        disabled={!accuracy || photoMatch === null} />
    </Screen>
  );
}
