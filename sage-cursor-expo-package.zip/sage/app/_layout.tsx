import React, { createContext, useContext, useEffect, useState } from "react";
import { Stack } from "expo-router";
import { useFonts, InstrumentSans_400Regular, InstrumentSans_500Medium, InstrumentSans_600SemiBold } from "@expo-google-fonts/instrument-sans";
import { InstrumentSerif_400Regular } from "@expo-google-fonts/instrument-serif";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase";
import { configurePurchases } from "@/lib/purchases";
import { colors } from "@/constants/theme";

const AuthContext = createContext<{ session: Session | null; loading: boolean }>({
  session: null, loading: true,
});
export const useAuth = () => useContext(AuthContext);

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    InstrumentSans_400Regular, InstrumentSans_500Medium,
    InstrumentSans_600SemiBold, InstrumentSerif_400Regular,
  });
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      if (s?.user) configurePurchases(s.user.id).catch(() => {});
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  if (!fontsLoaded) return null;

  return (
    <AuthContext.Provider value={{ session, loading }}>
      <Stack screenOptions={{
        headerStyle: { backgroundColor: colors.bg },
        headerTintColor: colors.ink,
        headerShadowVisible: false,
        contentStyle: { backgroundColor: colors.bg },
      }}>
        <Stack.Screen name="index" options={{ headerShown: false }} />
        <Stack.Screen name="onboarding" options={{ headerShown: false }} />
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="paywall" options={{ presentation: "modal", title: "Sage+" }} />
      </Stack>
    </AuthContext.Provider>
  );
}
