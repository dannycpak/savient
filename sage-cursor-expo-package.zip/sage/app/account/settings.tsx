// Account settings — name/email (re-verify), change password, delete (soft + 30-day purge).
import { useEffect, useState } from "react";
import { Alert, Text } from "react-native";
import { router } from "expo-router";
import { supabase } from "@/lib/supabase";
import { Screen, Button, Field } from "@/components/ui";
import { space, type } from "@/constants/theme";

export default function Settings() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? ""));
    supabase.from("profiles").select("display_name").single()
      .then(({ data }) => setName(data?.display_name ?? ""));
  }, []);

  const save = async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) return;
    await supabase.from("profiles").update({ display_name: name }).eq("id", data.user.id);
    if (data.user?.email !== email) {
      const { error } = await supabase.auth.updateUser({ email });
      if (error) return Alert.alert("Couldn't update email", error.message);
      Alert.alert("Verify your new email", "Check your inbox to confirm the change.");
    } else {
      Alert.alert("Saved");
    }
  };

  const deleteAccount = () => {
    Alert.alert("Delete account?",
      "Your account is deactivated now and permanently deleted after 30 days.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete", style: "destructive",
          onPress: async () => {
            const { data } = await supabase.auth.getUser();
            if (data.user) {
              await supabase.from("profiles")
                .update({ deleted_at: new Date().toISOString() })
                .eq("id", data.user.id);
            }
            await supabase.auth.signOut();
            router.replace("/onboarding");
          },
        },
      ]);
  };

  return (
    <Screen style={{ gap: space.md }}>
      <Text style={type.h1}>Account</Text>
      <Field label="Full name" value={name} onChangeText={setName} />
      <Field label="Email" value={email} onChangeText={setEmail}
        autoCapitalize="none" keyboardType="email-address" />
      <Button label="Save changes" onPress={save} />
      <Button label="Change password" variant="ghost"
        onPress={() => router.push("/(auth)/forgot-password")} />
      <Button label="Delete account" variant="danger" onPress={deleteAccount} />
    </Screen>
  );
}
