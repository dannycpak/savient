// Billing — subscription state, credits, deep-link to platform subscription management.
import { useEffect, useState } from "react";
import { Linking, Platform, Text } from "react-native";
import { supabase } from "@/lib/supabase";
import { Screen, Card, Button, Eyebrow } from "@/components/ui";
import { space, type } from "@/constants/theme";

export default function Billing() {
  const [sub, setSub] = useState<any>(null);
  const [credits, setCredits] = useState(0);

  useEffect(() => {
    supabase.from("subscriptions").select("*").maybeSingle().then(({ data }) => setSub(data));
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const { data: bal } = await supabase.rpc("credit_balance", { p_user: data.user.id });
      setCredits(bal ?? 0);
    });
  }, []);

  const manage = () => {
    // Cancel/manage happens in the platform's subscription UI; state returns via webhook.
    Linking.openURL(Platform.OS === "ios"
      ? "https://apps.apple.com/account/subscriptions"
      : "https://play.google.com/store/account/subscriptions");
  };

  return (
    <Screen style={{ gap: space.md }}>
      <Text style={type.h1}>Subscription & billing</Text>
      <Card>
        <Eyebrow>Sage+</Eyebrow>
        <Text style={type.h2}>{sub ? sub.status : "Not subscribed"}</Text>
        {sub?.renews_at && <Text style={type.caption}>
          Renews {new Date(sub.renews_at).toLocaleDateString()}
        </Text>}
      </Card>
      <Card>
        <Eyebrow>Visual Check credits</Eyebrow>
        <Text style={type.h2}>{credits}</Text>
      </Card>
      <Button label="Manage subscription" variant="ghost" onPress={manage} />
    </Screen>
  );
}
