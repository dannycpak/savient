// Splash / route gate: onboarding → auth → tabs.
import { Redirect } from "expo-router";
import { ActivityIndicator, View } from "react-native";
import { useAuth } from "./_layout";
import { colors } from "@/constants/theme";

export default function Index() {
  const { session, loading } = useAuth();
  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.green} />
      </View>
    );
  }
  return session ? <Redirect href="/(tabs)" /> : <Redirect href="/onboarding" />;
}
