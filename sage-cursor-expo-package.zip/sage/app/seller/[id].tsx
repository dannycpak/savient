// Seller profile — credibility score, tier badge, recent rating breakdown.
import { useEffect, useState } from "react";
import { Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { supabase } from "@/lib/supabase";
import { Screen, Card, Eyebrow } from "@/components/ui";
import { space, type } from "@/constants/theme";

const TIER_LABEL: Record<string, string> = {
  self_certified: "Self-certified",
  documented: "Documented sourcing",
  lab_verified: "Lab-verified",
};

export default function Seller() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [seller, setSeller] = useState<any>(null);
  const [ratings, setRatings] = useState<any[]>([]);

  useEffect(() => {
    supabase.from("sellers").select("*").eq("id", id).single()
      .then(({ data }) => setSeller(data));
    supabase.from("ratings").select("accuracy, photo_match, created_at")
      .eq("seller_id", id).order("created_at", { ascending: false }).limit(10)
      .then(({ data }) => setRatings(data ?? []));
  }, [id]);

  if (!seller) return <Screen />;
  const asDescribed = ratings.filter((r) => r.accuracy === "as_described").length;
  const photoMatched = ratings.filter((r) => r.photo_match).length;

  return (
    <Screen style={{ gap: space.md }}>
      <Text style={type.h1}>{seller.business_name ?? "Seller"}</Text>
      <Card>
        <Eyebrow>Credibility</Eyebrow>
        <Text style={type.hero}>{Number(seller.credibility_score).toFixed(1)}/10</Text>
        <Text style={type.caption}>
          {TIER_LABEL[seller.tier]} · {seller.ratings_count} ratings on material accuracy
        </Text>
      </Card>
      <Card>
        <Eyebrow>Recent ratings</Eyebrow>
        <View style={{ gap: 4 }}>
          <Text style={type.body}>Locality as described: {asDescribed}/{ratings.length || 0}</Text>
          <Text style={type.body}>Photos matched the piece: {photoMatched}/{ratings.length || 0}</Text>
        </View>
      </Card>
    </Screen>
  );
}
