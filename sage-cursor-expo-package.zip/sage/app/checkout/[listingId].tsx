// Checkout status — escrow explainer + order state. Phase 4 wires PaymentSheet + tracking.
import { useLocalSearchParams } from "expo-router";
import { Text } from "react-native";
import { Screen, Card, Eyebrow } from "@/components/ui";
import { ESCROW_EXPLAINER } from "@/constants/copy";
import { space, type } from "@/constants/theme";

export default function Checkout() {
  const { listingId } = useLocalSearchParams<{ listingId: string }>();
  return (
    <Screen style={{ gap: space.md }}>
      <Text style={type.h1}>Order placed</Text>
      <Card>
        <Eyebrow>Payment held in escrow</Eyebrow>
        <Text style={type.body}>{ESCROW_EXPLAINER.held}</Text>
      </Card>
      <Card>
        <Eyebrow>Tracked shipping</Eyebrow>
        <Text style={type.body}>{ESCROW_EXPLAINER.shipping}</Text>
      </Card>
      <Text style={type.caption}>Listing: {listingId}</Text>
    </Screen>
  );
}
