// Profile — plan, checks left, credits, links to account/billing, sign out.
import { useCallback, useState } from "react";
import { Text, View } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { supabase } from "@/lib/supabase";
import { FREE_TIER } from "@/constants/copy";
import { Screen, Card, Button, Eyebrow } from "@/components/ui";
import { space, type } from "@/constants/theme";

export default function Profile() {
  const [plan, setPlan] = useState<"free" | "plus">("free");
  const [checksUsed, setChecksUsed] = useState(0);
  const [credits, setCredits] = useState(0);

  useFocusEffect(useCallback(() => {
    (async () => {
      const { data: p } = await supabase.from("profiles")
        .select("plan, checks_used_month").single();
      if (p) { setPlan(p.plan); setChecksUsed(p.checks_used_month); }
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: bal } = await supabase.rpc("credit_balance", { p_user: user.id });
        setCredits(bal ?? 0);
      }
    })();
  }, []));

  const checksLeft = plan === "plus"
    ? "Unlimited"
    : `${Math.max(0, FREE_TIER.checksPerMonth - checksUsed)} of ${FREE_TIER.checksPerMonth} left`;

  return (
    <Screen style={{ gap: space.md }}>
      <Card>
        <Eyebrow>Plan</Eyebrow>
        <Text style={type.h1}>{plan === "plus" ? "Sage+" : "Free"}</Text>
        <Text style={type.caption}>Visual Checks this month: {checksLeft}</Text>
        <Text style={type.caption}>Credits: {credits}</Text>
      </Card>
      {plan === "free" && <Button label="Go unlimited with Sage+" onPress={() => router.push("/paywall")} />}
      <Button label="Account settings" variant="ghost" onPress={() => router.push("/account/settings")} />
      <Button label="Subscription & billing" variant="ghost" onPress={() => router.push("/account/billing")} />
      <View style={{ flex: 1 }} />
      <Button label="Sign out" variant="ghost" onPress={async () => {
        await supabase.auth.signOut();
        router.replace("/onboarding");
      }} />
    </Screen>
  );
}
