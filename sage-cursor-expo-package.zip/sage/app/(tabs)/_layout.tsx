import { Tabs } from "expo-router";
import { Text } from "react-native";
import { colors, fonts } from "@/constants/theme";

const icon = (glyph: string) => ({ color }: { color: string }) => (
  <Text style={{ fontSize: 20, color }}>{glyph}</Text>
);

export default function TabsLayout() {
  return (
    <Tabs screenOptions={{
      headerStyle: { backgroundColor: colors.bg }, headerShadowVisible: false,
      headerTintColor: colors.ink,
      headerTitleStyle: { fontFamily: fonts.semibold },
      tabBarStyle: { backgroundColor: colors.bg, borderTopColor: colors.line },
      tabBarActiveTintColor: colors.green, tabBarInactiveTintColor: colors.faint,
      tabBarLabelStyle: { fontFamily: fonts.medium, fontSize: 11 },
    }}>
      <Tabs.Screen name="index"   options={{ title: "Home",    tabBarIcon: icon("⌂") }} />
      <Tabs.Screen name="catalog" options={{ title: "Catalog", tabBarIcon: icon("▦") }} />
      <Tabs.Screen name="check"   options={{ title: "Check",   tabBarIcon: icon("◉") }} />
      <Tabs.Screen name="market"  options={{ title: "Market",  tabBarIcon: icon("⚖") }} />
      <Tabs.Screen name="profile" options={{ title: "Profile", tabBarIcon: icon("◍") }} />
    </Tabs>
  );
}
