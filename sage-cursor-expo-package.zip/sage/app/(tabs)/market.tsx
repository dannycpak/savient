// Marketplace feed — active listings with seller credibility badges.
import { useCallback, useState } from "react";
import { FlatList, Pressable, Text, View } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { supabase } from "@/lib/supabase";
import { Screen, Card } from "@/components/ui";
import { space, type, colors } from "@/constants/theme";

type Row = {
  id: string; title: string; species: string | null; price_cents: number;
  sellers: { id: string; business_name: string | null; credibility_score: number; tier: string };
};

const TIER_LABEL: Record<string, string> = {
  self_certified: "Self-certified",
  documented: "Documented sourcing",
  lab_verified: "Lab-verified",
};

export default function Market() {
  const [rows, setRows] = useState<Row[]>([]);
  useFocusEffect(useCallback(() => {
    supabase.from("listings")
      .select("id, title, species, price_cents, sellers ( id, business_name, credibility_score, tier )")
      .eq("status", "active").order("created_at", { ascending: false })
      .then(({ data }) => setRows((data as unknown as Row[]) ?? []));
  }, []));

  return (
    <Screen>
      <FlatList
        data={rows}
        keyExtractor={(r) => r.id}
        contentContainerStyle={{ gap: space.sm }}
        ListEmptyComponent={<Card><Text style={type.body}>No active listings yet.</Text></Card>}
        renderItem={({ item }) => (
          <Pressable onPress={() => router.push(`/listing/${item.id}`)}>
            <Card>
              <Text style={type.h2}>{item.title}</Text>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 4 }}>
                <Text style={type.caption}>
                  {item.sellers?.business_name ?? "Seller"} · {item.sellers?.credibility_score?.toFixed(1)}/10
                  · {TIER_LABEL[item.sellers?.tier] ?? ""}
                </Text>
                <Text style={[type.caption, { color: colors.ink }]}>
                  ${(item.price_cents / 100).toLocaleString()}
                </Text>
              </View>
            </Card>
          </Pressable>
        )}
      />
    </Screen>
  );
}
