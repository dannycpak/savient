// Home — collection value headline, Visual Check CTA, recent activity, rating prompts.
import { useCallback, useState } from "react";
import { ScrollView, Text, View } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { supabase } from "@/lib/supabase";
import { Screen, Card, Button, Eyebrow } from "@/components/ui";
import { colors, space, type } from "@/constants/theme";

export default function Home() {
  const [valueCents, setValueCents] = useState<number | null>(null);
  const [count, setCount] = useState(0);
  const [pendingRatings, setPendingRatings] = useState<{ id: string; title: string }[]>([]);

  useFocusEffect(useCallback(() => {
    (async () => {
      const { data: specimens } = await supabase
        .from("specimens").select("est_value_cents");
      if (specimens) {
        setCount(specimens.length);
        setValueCents(specimens.reduce((s, r) => s + (r.est_value_cents ?? 0), 0));
      }
      // Delivered-but-unrated orders drive the required quick-rating loop.
      const { data: orders } = await supabase
        .from("orders")
        .select("id, listings ( title ), ratings ( id )")
        .in("status", ["delivered", "released"]);
      setPendingRatings(
        (orders ?? [])
          .filter((o) => !(o.ratings as unknown[])?.length)
          .map((o) => ({
            id: o.id,
            title: (o.listings as unknown as { title: string })?.title ?? "purchase",
          })),
      );
    })();
  }, []));

  return (
    <Screen style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: space.lg, gap: space.md }}>
        <Card>
          <Eyebrow>Collection value</Eyebrow>
          <Text style={type.hero}>
            {valueCents === null ? "—" : `$${(valueCents / 100).toLocaleString()}`}
          </Text>
          <Text style={type.caption}>{count} specimens cataloged</Text>
        </Card>

        <Button label="Run a Visual Check" onPress={() => router.push("/(tabs)/check")} />

        {pendingRatings.map((p) => (
          <Card key={p.id} style={{ borderColor: colors.green }}>
            <Text style={type.h2}>Rate your {p.title} purchase</Text>
            <Text style={type.caption}>Quick accuracy rating — it powers seller credibility.</Text>
            <View style={{ height: space.sm }} />
            <Button label="Rate now" variant="ghost" onPress={() => router.push(`/rate/${p.id}`)} />
          </Card>
        ))}

        <Card>
          <Eyebrow>Recent activity</Eyebrow>
          <Text style={type.caption}>
            Activity from your catalog and price-range updates appears here.
          </Text>
        </Card>
      </ScrollView>
    </Screen>
  );
}
