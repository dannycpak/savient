// Minimal shared UI kit in the Sage design language. Extend here, not inline in screens.
import React from "react";
import {
  Pressable, Text, TextInput, View, ActivityIndicator,
  type ViewStyle, type TextInputProps,
} from "react-native";
import { colors, fonts, radius, space, type } from "@/constants/theme";

export function Screen({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return (
    <View style={[{ flex: 1, backgroundColor: colors.bg, padding: space.lg }, style]}>
      {children}
    </View>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return (
    <View style={[{
      backgroundColor: colors.surface, borderRadius: radius.lg,
      padding: space.md, borderWidth: 1, borderColor: colors.line,
    }, style]}>
      {children}
    </View>
  );
}

export function Button({
  label, onPress, variant = "primary", loading, disabled,
}: {
  label: string; onPress: () => void;
  variant?: "primary" | "ghost" | "danger"; loading?: boolean; disabled?: boolean;
}) {
  const bg = variant === "primary" ? colors.green : variant === "danger" ? colors.danger : "transparent";
  const fg = variant === "ghost" ? colors.green : "#FFFFFF";
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => ({
        backgroundColor: pressed && variant === "primary" ? colors.greenDeep : bg,
        borderRadius: radius.pill, paddingVertical: 14, alignItems: "center",
        opacity: disabled ? 0.5 : 1,
        borderWidth: variant === "ghost" ? 1 : 0, borderColor: colors.green,
      })}
    >
      {loading
        ? <ActivityIndicator color={fg} />
        : <Text style={{ fontFamily: fonts.semibold, fontSize: 16, color: fg }}>{label}</Text>}
    </Pressable>
  );
}

export function Field(props: TextInputProps & { label?: string }) {
  return (
    <View style={{ gap: space.xs }}>
      {props.label ? <Text style={type.eyebrow}>{props.label}</Text> : null}
      <TextInput
        placeholderTextColor={colors.faint}
        {...props}
        style={{
          backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line,
          borderRadius: radius.md, padding: 14, fontFamily: fonts.body,
          fontSize: 15, color: colors.ink,
        }}
      />
    </View>
  );
}

export function Eyebrow({ children }: { children: string }) {
  return <Text style={type.eyebrow}>{children}</Text>;
}
